<center>

<img src="./netflix.png" alt="amazon Poster"/>

</center>
