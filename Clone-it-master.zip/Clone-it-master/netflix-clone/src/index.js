import React from "react";
import ReactDOM from "react-dom";
import App from "./App";

ReactDOM.render(
  <div>
    <App />
  </div>,
  document.getElementById("root")
);
//api key
//4a6fd5c43b94e7c2b26f73a1ddf3438a
//https://api.themoviedb.org/3/movie/550?api_key=4a6fd5c43b94e7c2b26f73a1ddf3438a
