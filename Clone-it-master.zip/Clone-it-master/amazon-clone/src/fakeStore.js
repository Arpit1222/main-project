const Store = {
  electronics: "https://fakestoreapi.com/products/category/electronics",
  jewelery: "https://fakestoreapi.com/products/category/jewelery",
  mensclothing: "https://fakestoreapi.com/products/category/men's%20clothing",
  womensclothing:
    "https://fakestoreapi.com/products/category/women's%20clothing",
};

export default Store;
