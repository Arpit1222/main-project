<center>

<img src="./poster.png" alt="amazon Poster"/>

</center>

| App Name  | Hosted URL                                                    |
| --------- | ------------------------------------------------------------- |
| Amazon    | [visit ↗](https://clone-9a6c5.firebaseapp.com/)               |
| Google    | [visit ↗](https://clone-d1ff9.web.app/)                       |
| Instagram | [visit ↗](https://instagram-clone-app-4f17f.firebaseapp.com/) |
| Messenger | [visit ↗](https://messanger-clone-6d383.firebaseapp.com/)     |
| Netflix   | [visit ↗](https://netflix-clone-5cd59.firebaseapp.com/)       |
